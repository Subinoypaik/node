const express=require('express');
const path=require('path');
const UserModel=require('../models/user');
const PostModel=require('../models/post');
const CommentModel=require('../models/comment');

//  comment get //
exports.index =  (req,res)=>{
    // res.render("home",{ 
    //     title: "users",
    // })
    CommentModel.find().populate("user").populate("post").exec((err,data)=>{
        if(!err){
            res.status(200).json({
                status:"success",
                result:data,
                message:"data fetch successfully"
            })
        }else{
            res.status(404).json({
                status:"faild",
                result:err,
                message:"data fetch faild"
            })
        }
    })
}


//store user data api.
exports.addUserstore=(req,res)=>{
    UserModel({
        name:req.body.name,
        email:req.body.email,
        phone:req.body.phone
    }).save().then(result=>{
        res.status(201).json({
            status:"success",
            data:result,
            message:"data fetch successfully"
        })
      
        
    }).catch(error=>{
        res.status(404).json({
            status:"faild",
            err:result,
            message:"data fetch faild"
        })
        
    })
}


//store post data api.
exports.addPoststore=(req,res)=>{
    PostModel({
        post:req.body.name,
        user:req.body.post
    }).save().then(result=>{
        res.status(201).json({
            status:"success",
            data:result,
            message:"data fetch successfully"
        })
      
        
    }).catch(error=>{
        res.status(404).json({
            status:"faild",
            err:result,
            message:"data fetch faild"
        })
        
    })
}


///store comment data api.
exports.addCommentstore=(req,res,next)=>{
    CommentModel({
        user:req.body.name,
        post:req.body.post,
        comment:req.body.comment
    }).save().then(result=>{
        res.status(201).json({
            status:"success",
            data:result,
            message:"data fetch successfully"
        })
      
        
    }).catch(error=>{
        res.status(404).json({
            status:"faild",
            err:result,
            message:"data fetch faild"
        })
        
    })
}