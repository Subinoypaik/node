const express=require('express');
const path=require('path');
const UserModel=require('../models/user');
const PostModel=require('../models/post');
const CommentModel=require('../models/comment');

// table user //
exports.index =  (req,res)=>{
    // res.render("home",{ 
    //     title: "users",
    // })
    CommentModel.find().populate("user").populate("post").exec((err,data)=>{
        if(!err){
            console.log(data);
            res.render('home',{
                title:' user',
                displaydata:data,
             
            })
        }
    })
}


// add  user form//
exports.adduser =  (req,res)=>{
    res.render("adduser",{
        title:"Add User"
    }
   )
}

//store user data controller.
exports.addUserstore=(req,res)=>{
    UserModel({
        name:req.body.name,
        email:req.body.email,
        phone:req.body.phone
    }).save().then(result=>{
        console.log('User added...');
        res.redirect('/addpost');
    }).catch(error=>{
        console.log(error);
    })
}


// Post//
exports.addpost=((req,res)=>{
    UserModel.find().then(result=>{
        res.render('addpost',{
            title:'Add Post',
            users:result
        })
    }).catch(error=>{
        console.log(error);
    })
})



//store post data //
exports.addPoststore=(req,res)=>{
    PostModel({
        post:req.body.name,
        user:req.body.post
    }).save().then(result=>{
        console.log(result,`Post added...`);
        res.redirect('/addcomment');
    }).catch(error=>{
        console.log(error);
    })
}



// commen//

exports.addcomment=(req,res)=>{
    UserModel.find().then(result1=>{
        PostModel.find().then(result2=>{
            res.render('addComment',{
                title:'Add  Comments',
                displaydata1:result1,
                displaydata2:result2,
            })
        })
    })
}



exports.addCommentstore=(req,res)=>{
    CommentModel({
        user:req.body.name,
        post:req.body.post,
        comment:req.body.comment
    }).save().then(result=>{
        console.log(`Comment added...`);
        res.redirect('/');
    }).catch(error=>{
        console.log(error);
    })
}