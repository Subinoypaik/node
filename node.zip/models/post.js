const mongoose=require('mongoose');
const Schema=mongoose.Schema;

const PostSchema=new Schema({
    user:{
        type:Schema.Types.ObjectId,
        ref:'user'
    },
    post:{
        type:String,
        required:true
    }
});

const PostModel=new mongoose.model('post',PostSchema);
module.exports=PostModel;