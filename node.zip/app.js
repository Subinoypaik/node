const express = require("express");
const ejs = require("ejs");
const path = require("path")
const  mongoose =require("mongoose");
const bodyparser =require("body-parser")

const port = process.env.PORT || 4006
app = express();

const db = "mongodb+srv://blog2:blog2123@cluster0.rkhcc.mongodb.net/blog3?retryWrites=true&w=majority"
// urlencoded//
app.use(express.urlencoded({
    extended: true
}));

// parse application/x-www-form-urlencoded
app.use(bodyparser.urlencoded({ extended: false }))
// parse application/json
app.use(bodyparser.json())

 // ejs//
//set view engine
app.set('view engine', 'ejs');
app.set('views', 'views');

// Public //
app.use(express.static(path.join(__dirname,"public")))



//  Router //
const approuter = require("./route/approute");
app.use(approuter)


// api Router //
const apirouter = require("./route/apirouter")
app.use(apirouter)






 mongoose.connect(db,{
    useNewUrlParser:true,
    useUnifiedTopology:true
 }).then(()=>{
     
 app.listen(port,()=>{
    console.log(`this is my server url http://localhost:${port}`);
    console.log("connection successfull");
})
 }).catch(()=>{
    console.log("connection faild");
 })