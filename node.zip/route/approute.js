const express = require("express");
 const  route = express.Router();
appcontroller = require("../controller/appcontroller");



// Add User//
route.get("/",appcontroller.index)
route.get("/adduser",appcontroller.adduser)
route.post('/addstore',appcontroller.addUserstore);

//Post//
route.get("/addpost",appcontroller.addpost)
route.post("/poststore",appcontroller.addPoststore)


//Comment//
route.get("/addcomment",appcontroller.addcomment)
route.post("/addcommentstore",appcontroller.addCommentstore)

module.exports = route;