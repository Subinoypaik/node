const express = require("express");
 const  Route = express.Router();
apicontroller = require("../controller/apicontroller");

Route.get('/api',apicontroller.index);
Route.post("/apiuser",apicontroller.addUserstore);
Route.post("/apipost",apicontroller.addPoststore);
Route.post("/apicomment",apicontroller.addCommentstore)
module.exports = Route